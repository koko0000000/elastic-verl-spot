#!/usr/bin/env bash
set -euo pipefail
set -x

# Node 1: Ray head + driver node + one logical training node.
# Start this first. Then start one train worker node and two rollout worker nodes.

RAY_HEAD_ADDR=${RAY_HEAD_ADDR:-$(hostname -I | awk '{print $1}')}
RAY_HEAD_PORT=${RAY_HEAD_PORT:-6379}
RAY_DASHBOARD_PORT=${RAY_DASHBOARD_PORT:-8265}

RAY_NODE_MANAGER_PORT=${RAY_NODE_MANAGER_PORT:-11001}
RAY_OBJECT_MANAGER_PORT=${RAY_OBJECT_MANAGER_PORT:-11002}
RAY_MIN_WORKER_PORT=${RAY_MIN_WORKER_PORT:-12000}
RAY_MAX_WORKER_PORT=${RAY_MAX_WORKER_PORT:-12100}

export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}

ray stop --force || true

ray start --head \
  --node-ip-address="${RAY_HEAD_ADDR}" \
  --port="${RAY_HEAD_PORT}" \
  --dashboard-host=0.0.0.0 \
  --dashboard-port="${RAY_DASHBOARD_PORT}" \
  --node-manager-port="${RAY_NODE_MANAGER_PORT}" \
  --object-manager-port="${RAY_OBJECT_MANAGER_PORT}" \
  --min-worker-port="${RAY_MIN_WORKER_PORT}" \
  --max-worker-port="${RAY_MAX_WORKER_PORT}" \
  --num-gpus=1 \
  --resources='{"train": 1}'

export RAY_ADDRESS="${RAY_HEAD_ADDR}:${RAY_HEAD_PORT}"

echo "[INFO] Ray head started at ${RAY_ADDRESS}"
echo "[INFO] Start the other nodes, then run:"
echo "python3 -u elastic_spot_experiments/mock_4node_h100_rollout_exit.py"

