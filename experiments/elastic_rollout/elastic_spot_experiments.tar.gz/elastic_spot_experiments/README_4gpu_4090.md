# 4-GPU 4090 Logical-Node Experiments

This folder contains first-step experiments for developing elastic rollout
logic on a single 4-GPU 4090 instance.

The goal is not to emulate physical Ray nodes. Instead, one Ray cluster is
started on the machine and four logical workers are created:

- `train-0`: training placeholder, uses one GPU.
- `train-1`: training placeholder, uses one GPU.
- `rollout-0`: rollout worker, uses one GPU.
- `rollout-1`: rollout worker, uses one GPU.

This is enough for developing the first rollout-failure features:

- rollout worker registration;
- request assignment;
- request retry after worker exit;
- trajectory buffer persistence;
- training-side insensitivity to rollout worker failure.

## Files

`run_4gpu4090_grpo_sync_baseline.sh`

Runs a small synchronous GRPO baseline through `verl.trainer.main_ppo` on one
machine with four GPUs. This is the reference run that proves the local 4-GPU
4090 environment can complete a normal verl GRPO step.

`mock_4logical_nodes_rollout_exit.py`

Runs a local Ray simulation with two training actors and two rollout actors.
One rollout actor is killed during the experiment. The scheduler requeues
unfinished requests and writes completed trajectories to JSONL.

`run_mock_4logical_nodes_rollout_exit.sh`

Convenience wrapper for the mock rollout-exit experiment.

## Recommended Order

1. Run the native GRPO baseline:

```bash
bash elastic_spot_experiments/run_4gpu4090_grpo_sync_baseline.sh \
  MODEL_PATH=/path/to/model \
  DATA_DIR=/path/to/gsm8k
```

2. Run the mock rollout-exit experiment:

```bash
bash elastic_spot_experiments/run_mock_4logical_nodes_rollout_exit.sh
```

3. Confirm these success conditions:

- all requests end in `done`;
- killed rollout worker has running requests requeued;
- `mock_outputs/trajectories.jsonl` contains one trajectory per request;
- training actors keep heartbeating while rollout failure/retry happens.

## Notes

This mock experiment intentionally uses fake responses. It is the fastest way
to validate request retry and trajectory buffer behavior before connecting a
real vLLM/SGLang rollout server or modifying verl's `generate_sequences` path.

