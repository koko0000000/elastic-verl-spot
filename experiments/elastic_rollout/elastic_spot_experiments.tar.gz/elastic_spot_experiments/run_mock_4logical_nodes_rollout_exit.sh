#!/usr/bin/env bash
set -euo pipefail
set -x

# Run a local Ray simulation with:
#   2 logical training workers + 2 logical rollout workers.
# One rollout worker is killed while requests are in flight.

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-"0,1,2,3"}
export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}

ray stop --force || true
ray start --head \
  --node-ip-address=127.0.0.1 \
  --port=6379 \
  --dashboard-host=0.0.0.0 \
  --dashboard-port=8265 \
  --num-gpus=4

export RAY_ADDRESS=${RAY_ADDRESS:-"127.0.0.1:6379"}

python3 -u elastic_spot_experiments/mock_4logical_nodes_rollout_exit.py "$@"

