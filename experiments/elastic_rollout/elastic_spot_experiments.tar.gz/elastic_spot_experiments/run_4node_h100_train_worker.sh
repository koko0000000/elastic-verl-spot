#!/usr/bin/env bash
set -euo pipefail
set -x

# Node 2: Ray worker with one H100 reserved for logical training.

RAY_HEAD_ADDR=${RAY_HEAD_ADDR:-10.245.247.247}
RAY_HEAD_PORT=${RAY_HEAD_PORT:-6379}

export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}

ray stop --force || true

ray start --address="${RAY_HEAD_ADDR}:${RAY_HEAD_PORT}" \
  --num-gpus=1 \
  --resources='{"train": 1}' \
  --block

