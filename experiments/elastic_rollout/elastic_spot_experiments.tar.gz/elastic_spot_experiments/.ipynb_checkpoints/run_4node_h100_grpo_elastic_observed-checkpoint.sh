#!/usr/bin/env bash
set -euo pipefail
set -x

# Full GRPO smoke test with the first-stage elastic rollout shim enabled.
# This does not replace verl's rollout engine yet. It keeps native
# generate_sequences output so the complete RL path can reach optimizer.step(),
# while writing request-level elastic events for each rollout batch.

export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}
export RAY_ADDRESS=${RAY_ADDRESS:-"auto"}

MODEL_PATH=${MODEL_PATH:-/inspire/hdd/global_public/public_models/Qwen/Qwen2.5-0.5B-Instruct}
TRAIN_FILES=${TRAIN_FILES:-/inspire/hdd/project/ruanyinyitihua/czxs253130626/klg/verl/data/gsm8k/train.parquet}
VAL_FILES=${VAL_FILES:-/inspire/hdd/project/ruanyinyitihua/czxs253130626/klg/verl/data/gsm8k/test.parquet}
OUTPUT_DIR=${OUTPUT_DIR:-elastic_spot_experiments/full_rl_outputs}
RUN_ID=${RUN_ID:-$(date +%Y%m%d_%H%M%S)}
RUN_OUTPUT_DIR=${RUN_OUTPUT_DIR:-${OUTPUT_DIR}/${RUN_ID}}
EVENT_LOG_PATH=${EVENT_LOG_PATH:-${RUN_OUTPUT_DIR}/elastic_rollout_events.jsonl}

mkdir -p "${RUN_OUTPUT_DIR}"

python3 -u -m verl.trainer.main_ppo \
  data.train_files="${TRAIN_FILES}" \
  data.val_files="${VAL_FILES}" \
  data.max_prompt_length=256 \
  data.max_response_length=512 \
  data.train_batch_size=8 \
  data.val_batch_size=8 \
  data.shuffle=False \
  data.filter_overlong_prompts=False \
  data.truncation=left \
  algorithm.adv_estimator=grpo \
  algorithm.use_kl_in_reward=False \
  algorithm.norm_adv_by_std_in_grpo=True \
  actor_rollout_ref.model.path="${MODEL_PATH}" \
  actor_rollout_ref.model.use_remove_padding=True \
  actor_rollout_ref.model.enable_gradient_checkpointing=True \
  actor_rollout_ref.hybrid_engine=True \
  actor_rollout_ref.actor.strategy=fsdp \
  actor_rollout_ref.actor.optim.lr=1e-6 \
  actor_rollout_ref.actor.ppo_mini_batch_size=8 \
  actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.actor.use_dynamic_bsz=True \
  actor_rollout_ref.actor.use_kl_loss=False \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.rollout.name=vllm \
  actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.35 \
  actor_rollout_ref.rollout.n=2 \
  actor_rollout_ref.rollout.max_num_seqs=8 \
  actor_rollout_ref.rollout.max_model_len=768 \
  actor_rollout_ref.rollout.max_num_batched_tokens=768 \
  actor_rollout_ref.rollout.enforce_eager=True \
  actor_rollout_ref.rollout.calculate_log_probs=True \
  actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=1 \
  trainer.logger='["console"]' \
  trainer.project_name=elastic_verl_spot \
  trainer.experiment_name=grpo_elastic_observed_4node_h100 \
  trainer.n_gpus_per_node=1 \
  trainer.nnodes=4 \
  trainer.total_training_steps=3 \
  trainer.test_freq=-1 \
  trainer.save_freq=-1 \
  trainer.val_before_train=False \
  trainer.rollout_data_dir="${OUTPUT_DIR}/rollout_data" \
  trainer.elastic_rollout.enable=true \
  trainer.elastic_rollout.event_log_path="${EVENT_LOG_PATH}" \
  trainer.elastic_rollout.dry_run_fail_worker_id=rollout-0 \
  trainer.elastic_rollout.dry_run_fail_after_dispatches=-1 \
  trainer.elastic_rollout.fault_injection_enable="${FAULT_INJECTION_ENABLE:-false}" \
  trainer.elastic_rollout.fault_injection_step="${FAULT_INJECTION_STEP:--1}" \
  trainer.elastic_rollout.fault_injection_after_dispatches="${FAULT_INJECTION_AFTER_DISPATCHES:--1}" \
  trainer.elastic_rollout.fault_injection_server_index="${FAULT_INJECTION_SERVER_INDEX:-0}" \
  trainer.elastic_rollout.fault_injection_no_restart="${FAULT_INJECTION_NO_RESTART:-true}" \
  trainer.resume_mode=disable \
  "$@"
