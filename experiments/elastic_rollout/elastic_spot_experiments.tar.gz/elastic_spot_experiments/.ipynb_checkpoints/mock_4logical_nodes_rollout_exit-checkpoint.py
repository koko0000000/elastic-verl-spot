#!/usr/bin/env python3
"""Mock 4-logical-node rollout-exit experiment.

This experiment uses one local Ray cluster on a 4-GPU machine and creates:

- two training actors, each reserving one GPU;
- two rollout actors, each reserving one GPU;
- an in-driver scheduler with request retry and trajectory JSONL persistence.

It intentionally does not call vLLM or verl internals. The purpose is to
develop and verify rollout worker exit, request retry, and trajectory buffer
logic before wiring the manager into verl's rollout generation path.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import time
from typing import Any

import ray


@dataclass
class RequestState:
    """State tracked for one rollout request."""

    request_id: str
    prompt: str
    model_version: int
    status: str = "pending"
    assigned_worker: str | None = None
    attempts: int = 0
    response: str | None = None
    error: str | None = None


@dataclass
class TrajectoryRecord:
    """One completed mock trajectory."""

    request_id: str
    prompt: str
    response: str
    model_version: int
    worker_id: str
    attempts: int
    finished_at: float


@ray.remote(num_gpus=1)
class TrainWorker:
    """Placeholder training actor used to reserve one GPU and heartbeat."""

    def __init__(self, worker_id: str):
        self.worker_id = worker_id
        self.started_at = time.time()

    def heartbeat(self) -> dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "role": "train",
            "uptime_sec": time.time() - self.started_at,
        }


@ray.remote(num_gpus=1, max_restarts=0)
class RolloutWorker:
    """Mock rollout actor used to simulate generate latency and failure."""

    def __init__(self, worker_id: str, delay_sec: float):
        self.worker_id = worker_id
        self.delay_sec = delay_sec
        self.generated = 0

    def heartbeat(self) -> dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "role": "rollout",
            "generated": self.generated,
        }

    def generate(self, request: dict[str, Any]) -> dict[str, Any]:
        time.sleep(self.delay_sec)
        self.generated += 1
        return {
            "request_id": request["request_id"],
            "prompt": request["prompt"],
            "model_version": request["model_version"],
            "worker_id": self.worker_id,
            "response": f"mock_response_for_{request['request_id']}_by_{self.worker_id}",
        }


class JsonlTrajectoryStore:
    """Append-only JSONL trajectory buffer."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("", encoding="utf-8")

    def append(self, record: TrajectoryRecord) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(record), ensure_ascii=False) + "\n")


class InMemoryRolloutScheduler:
    """Small scheduler with retry and trajectory persistence."""

    def __init__(
        self,
        rollout_workers: dict[str, Any],
        trajectory_store: JsonlTrajectoryStore,
        max_attempts: int,
    ):
        self.rollout_workers = rollout_workers
        self.trajectory_store = trajectory_store
        self.max_attempts = max_attempts
        self.requests: dict[str, RequestState] = {}
        self.dead_workers: set[str] = set()

    def submit_requests(self, count: int, model_version: int) -> None:
        for idx in range(count):
            request_id = f"req-{idx:04d}"
            self.requests[request_id] = RequestState(
                request_id=request_id,
                prompt=f"mock prompt {idx}",
                model_version=model_version,
            )

    def _alive_worker_ids(self) -> list[str]:
        return [wid for wid in self.rollout_workers if wid not in self.dead_workers]

    def _pick_worker(self, request_idx: int) -> str:
        alive = self._alive_worker_ids()
        if not alive:
            raise RuntimeError("no alive rollout workers")
        return alive[request_idx % len(alive)]

    def _mark_worker_dead(self, worker_id: str) -> None:
        print(f"[scheduler] mark worker dead: {worker_id}")
        self.dead_workers.add(worker_id)
        for req in self.requests.values():
            if req.assigned_worker == worker_id and req.status == "running":
                print(f"[scheduler] requeue {req.request_id} from dead worker {worker_id}")
                req.status = "pending"
                req.assigned_worker = None
                req.error = f"worker_lost:{worker_id}"

    def run_until_done(self, fail_worker_id: str | None, fail_after_dispatches: int) -> None:
        in_flight: dict[Any, tuple[str, str, int]] = {}
        dispatches = 0
        fail_triggered = False

        while True:
            pending = [req for req in self.requests.values() if req.status == "pending"]
            if not pending and not in_flight:
                break

            for req in pending:
                if req.attempts >= self.max_attempts:
                    raise RuntimeError(f"{req.request_id} exceeded max attempts")

                worker_id = self._pick_worker(dispatches)
                worker = self.rollout_workers[worker_id]
                req.status = "running"
                req.assigned_worker = worker_id
                req.attempts += 1
                dispatches += 1

                attempt = req.attempts
                obj_ref = worker.generate.remote(asdict(req))
                in_flight[obj_ref] = (req.request_id, worker_id, attempt)
                print(f"[scheduler] dispatch {req.request_id} -> {worker_id}, attempt={req.attempts}")

                if (
                    fail_worker_id
                    and not fail_triggered
                    and dispatches >= fail_after_dispatches
                    and fail_worker_id not in self.dead_workers
                ):
                    print(f"[test] killing rollout worker {fail_worker_id}")
                    ray.kill(self.rollout_workers[fail_worker_id], no_restart=True)
                    self._mark_worker_dead(fail_worker_id)
                    fail_triggered = True

            if not in_flight:
                continue

            ready, _ = ray.wait(list(in_flight.keys()), num_returns=1, timeout=0.2)
            for ref in ready:
                request_id, worker_id, attempt = in_flight.pop(ref)
                req = self.requests[request_id]
                try:
                    result = ray.get(ref)
                except ray.exceptions.RayActorError as exc:
                    print(f"[scheduler] actor error for {request_id} on {worker_id}: {exc}")
                    self._mark_worker_dead(worker_id)
                    if (
                        req.status == "running"
                        and req.assigned_worker == worker_id
                        and req.attempts == attempt
                    ):
                        req.status = "pending"
                        req.assigned_worker = None
                    else:
                        print(
                            "[scheduler] ignore stale actor error "
                            f"{request_id} from {worker_id}, attempt={attempt}, "
                            f"current_status={req.status}, current_worker={req.assigned_worker}, "
                            f"current_attempt={req.attempts}"
                        )
                    continue

                if worker_id in self.dead_workers:
                    print(f"[scheduler] ignore stale result {request_id} from dead worker {worker_id}")
                    continue
                if req.status == "done":
                    print(f"[scheduler] ignore duplicate done result {request_id} from {worker_id}")
                    continue
                if req.assigned_worker != worker_id or req.attempts != attempt:
                    print(
                        "[scheduler] ignore stale result "
                        f"{request_id} from {worker_id}, attempt={attempt}, "
                        f"current_status={req.status}, current_worker={req.assigned_worker}, "
                        f"current_attempt={req.attempts}"
                    )
                    continue

                req.status = "done"
                req.response = result["response"]
                record = TrajectoryRecord(
                    request_id=req.request_id,
                    prompt=req.prompt,
                    response=req.response,
                    model_version=req.model_version,
                    worker_id=worker_id,
                    attempts=req.attempts,
                    finished_at=time.time(),
                )
                self.trajectory_store.append(record)
                print(f"[scheduler] done {request_id} by {worker_id}")

        not_done = [req for req in self.requests.values() if req.status != "done"]
        if not_done:
            raise RuntimeError(f"unfinished requests: {not_done}")

    def validate_trajectory_store(self) -> None:
        """Ensure the JSONL buffer has exactly one trajectory per request."""
        records = []
        with self.trajectory_store.path.open("r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    records.append(json.loads(line))

        expected = len(self.requests)
        seen_ids = [record["request_id"] for record in records]
        unique_ids = set(seen_ids)
        if len(records) != expected or len(unique_ids) != expected:
            duplicates = sorted({rid for rid in seen_ids if seen_ids.count(rid) > 1})
            raise RuntimeError(
                "trajectory buffer validation failed: "
                f"records={len(records)}, unique={len(unique_ids)}, expected={expected}, "
                f"duplicates={duplicates}"
            )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--num-requests", type=int, default=12)
    parser.add_argument("--model-version", type=int, default=1)
    parser.add_argument("--delay-sec", type=float, default=0.5)
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument("--fail-worker-id", default="rollout-0")
    parser.add_argument("--fail-after-dispatches", type=int, default=3)
    parser.add_argument(
        "--output-dir",
        default="./elastic_spot_experiments/mock_outputs",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    ray.init(address="auto", ignore_reinit_error=True)

    train_workers = {
        "train-0": TrainWorker.remote("train-0"),
        "train-1": TrainWorker.remote("train-1"),
    }
    rollout_workers = {
        "rollout-0": RolloutWorker.remote("rollout-0", args.delay_sec),
        "rollout-1": RolloutWorker.remote("rollout-1", args.delay_sec),
    }

    print("[driver] train heartbeats:")
    for hb in ray.get([worker.heartbeat.remote() for worker in train_workers.values()]):
        print(hb)

    output_dir = Path(args.output_dir)
    trajectory_store = JsonlTrajectoryStore(output_dir / "trajectories.jsonl")
    scheduler = InMemoryRolloutScheduler(
        rollout_workers=rollout_workers,
        trajectory_store=trajectory_store,
        max_attempts=args.max_attempts,
    )
    scheduler.submit_requests(count=args.num_requests, model_version=args.model_version)
    scheduler.run_until_done(
        fail_worker_id=args.fail_worker_id,
        fail_after_dispatches=args.fail_after_dispatches,
    )
    scheduler.validate_trajectory_store()

    done = [req for req in scheduler.requests.values() if req.status == "done"]
    retried = [req for req in done if req.attempts > 1]
    print(f"[result] done={len(done)} total={len(scheduler.requests)} retried={len(retried)}")
    print(f"[result] trajectory_jsonl={trajectory_store.path}")

    print("[driver] train heartbeats after rollout failure/retry:")
    for hb in ray.get([worker.heartbeat.remote() for worker in train_workers.values()]):
        print(hb)

    ray.shutdown()


if __name__ == "__main__":
    main()
