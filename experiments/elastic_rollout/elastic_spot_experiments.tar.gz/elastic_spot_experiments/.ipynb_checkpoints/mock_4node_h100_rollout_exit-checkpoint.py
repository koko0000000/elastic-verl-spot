#!/usr/bin/env python3
"""Mock 4-node H100 rollout-exit experiment.

Run this on the Ray head after four physical nodes have joined:

- 2 nodes started with custom resource {"train": 1}
- 2 nodes started with custom resource {"rollout": 1}

The driver creates two training actors and two rollout actors. Ray custom
resources force training actors onto train nodes and rollout actors onto rollout
nodes. One rollout actor is killed during request processing to simulate a
rollout instance exit.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import socket
import time
from typing import Any
from urllib import request as urllib_request
from urllib.error import URLError

import ray


@dataclass
class RequestState:
    """State tracked for one rollout request."""

    request_id: str
    prompt: str
    model_version: int
    status: str = "pending"
    assigned_worker: str | None = None
    attempts: int = 0
    response: str | None = None
    error: str | None = None


@dataclass
class TrajectoryRecord:
    """One completed mock trajectory."""

    request_id: str
    prompt: str
    response: str
    model_version: int
    worker_id: str
    hostname: str
    node_id: str
    attempts: int
    finished_at: float


class RuntimeInfo:
    """Helpers for recording where a Ray actor is running."""

    @staticmethod
    def current() -> dict[str, str]:
        return {
            "hostname": socket.gethostname(),
            "node_id": ray.get_runtime_context().get_node_id(),
        }


@ray.remote(num_gpus=1)
class TrainWorker:
    """Placeholder training actor used to reserve one GPU and heartbeat."""

    def __init__(self, worker_id: str):
        self.worker_id = worker_id
        self.started_at = time.time()
        self.runtime = RuntimeInfo.current()

    def heartbeat(self) -> dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "role": "train",
            "uptime_sec": time.time() - self.started_at,
            **self.runtime,
        }


@ray.remote(num_gpus=1, max_restarts=0)
class RolloutWorker:
    """Rollout actor with mock or HTTP-backed generation.

    The default backend is still mock so the existing control-plane test remains
    stable. When an HTTP endpoint is provided, the actor calls a vLLM
    OpenAI-compatible completions endpoint or an SGLang-style /generate endpoint.
    """

    def __init__(
        self,
        worker_id: str,
        delay_sec: float,
        backend: str = "mock",
        endpoint: str | None = None,
        timeout_sec: float = 120.0,
        served_model_name: str = "default",
        max_tokens: int = 64,
        temperature: float = 1.0,
    ):
        self.worker_id = worker_id
        self.delay_sec = delay_sec
        self.backend = backend
        self.endpoint = endpoint.rstrip("/") if endpoint else None
        self.timeout_sec = timeout_sec
        self.served_model_name = served_model_name
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.generated = 0
        self.runtime = RuntimeInfo.current()

    def heartbeat(self) -> dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "role": "rollout",
            "backend": self.backend,
            "endpoint": self.endpoint,
            "generated": self.generated,
            **self.runtime,
        }

    def _post_json(self, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps(payload).encode("utf-8")
        req = urllib_request.Request(
            url=url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib_request.urlopen(req, timeout=self.timeout_sec) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except URLError as exc:
            raise RuntimeError(f"HTTP rollout request failed: {url}: {exc}") from exc

    def _generate_http(self, request: dict[str, Any]) -> str:
        if not self.endpoint:
            raise RuntimeError("HTTP rollout backend requires endpoint")

        if self.backend == "vllm-openai":
            payload = {
                "model": request.get("model", "default"),
                "prompt": request["prompt"],
                "max_tokens": request.get("max_tokens", self.max_tokens),
                "temperature": request.get("temperature", self.temperature),
            }
            payload["model"] = request.get("model", self.served_model_name)
            result = self._post_json(f"{self.endpoint}/v1/completions", payload)
            return result["choices"][0]["text"]

        if self.backend == "sglang-generate":
            payload = {
                "text": request["prompt"],
                "sampling_params": {
                    "max_new_tokens": request.get("max_tokens", 64),
                    "temperature": request.get("temperature", self.temperature),
                },
            }
            payload["sampling_params"]["max_new_tokens"] = request.get("max_tokens", self.max_tokens)
            result = self._post_json(f"{self.endpoint}/generate", payload)
            if isinstance(result, dict):
                if "text" in result:
                    return result["text"]
                if "output" in result:
                    return result["output"]
                if "outputs" in result and result["outputs"]:
                    first = result["outputs"][0]
                    if isinstance(first, dict) and "text" in first:
                        return first["text"]
            return json.dumps(result, ensure_ascii=False)

        raise ValueError(f"unknown rollout backend: {self.backend}")

    def generate(self, request: dict[str, Any]) -> dict[str, Any]:
        time.sleep(self.delay_sec)
        self.generated += 1
        if self.backend == "mock":
            response = f"mock_response_for_{request['request_id']}_by_{self.worker_id}"
        else:
            response = self._generate_http(request)
        return {
            "request_id": request["request_id"],
            "prompt": request["prompt"],
            "model_version": request["model_version"],
            "worker_id": self.worker_id,
            "response": response,
            **self.runtime,
        }


class JsonlTrajectoryStore:
    """Append-only JSONL trajectory buffer."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("", encoding="utf-8")

    def append(self, record: TrajectoryRecord) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(record), ensure_ascii=False) + "\n")


class JsonlEventLogger:
    """Append-only JSONL event log for rollout scheduling decisions."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("", encoding="utf-8")

    def emit(self, event_type: str, **fields: Any) -> None:
        record = {
            "event_type": event_type,
            "ts": time.time(),
            **fields,
        }
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


class InMemoryRolloutScheduler:
    """Small scheduler with retry and trajectory persistence."""

    def __init__(
        self,
        rollout_workers: dict[str, Any],
        trajectory_store: JsonlTrajectoryStore,
        event_logger: JsonlEventLogger,
        max_attempts: int,
    ):
        self.rollout_workers = rollout_workers
        self.trajectory_store = trajectory_store
        self.event_logger = event_logger
        self.max_attempts = max_attempts
        self.requests: dict[str, RequestState] = {}
        self.dead_workers: set[str] = set()

    def submit_requests(self, count: int, model_version: int) -> None:
        for idx in range(count):
            request_id = f"req-{idx:04d}"
            self.requests[request_id] = RequestState(
                request_id=request_id,
                prompt=f"mock prompt {idx}",
                model_version=model_version,
            )
            self.event_logger.emit(
                "request_submitted",
                request_id=request_id,
                model_version=model_version,
            )

    def _alive_worker_ids(self) -> list[str]:
        return [wid for wid in self.rollout_workers if wid not in self.dead_workers]

    def _pick_worker(self, request_idx: int) -> str:
        alive = self._alive_worker_ids()
        if not alive:
            raise RuntimeError("no alive rollout workers")
        return alive[request_idx % len(alive)]

    def _mark_worker_dead(self, worker_id: str) -> None:
        print(f"[scheduler] mark worker dead: {worker_id}")
        self.dead_workers.add(worker_id)
        self.event_logger.emit("worker_dead", worker_id=worker_id)
        for req in self.requests.values():
            if req.assigned_worker == worker_id and req.status == "running":
                print(f"[scheduler] requeue {req.request_id} from dead worker {worker_id}")
                req.status = "pending"
                req.assigned_worker = None
                req.error = f"worker_lost:{worker_id}"
                self.event_logger.emit(
                    "request_requeued",
                    request_id=req.request_id,
                    worker_id=worker_id,
                    attempts=req.attempts,
                    reason=req.error,
                )

    def run_until_done(self, fail_worker_id: str | None, fail_after_dispatches: int) -> None:
        in_flight: dict[Any, tuple[str, str, int]] = {}
        dispatches = 0
        fail_triggered = False

        while True:
            pending = [req for req in self.requests.values() if req.status == "pending"]
            if not pending and not in_flight:
                break

            for req in pending:
                if req.attempts >= self.max_attempts:
                    raise RuntimeError(f"{req.request_id} exceeded max attempts")

                worker_id = self._pick_worker(dispatches)
                worker = self.rollout_workers[worker_id]
                req.status = "running"
                req.assigned_worker = worker_id
                req.attempts += 1
                attempt = req.attempts
                dispatches += 1

                obj_ref = worker.generate.remote(asdict(req))
                in_flight[obj_ref] = (req.request_id, worker_id, attempt)
                print(f"[scheduler] dispatch {req.request_id} -> {worker_id}, attempt={attempt}")
                self.event_logger.emit(
                    "request_dispatched",
                    request_id=req.request_id,
                    worker_id=worker_id,
                    attempt=attempt,
                )

                if (
                    fail_worker_id
                    and not fail_triggered
                    and dispatches >= fail_after_dispatches
                    and fail_worker_id not in self.dead_workers
                ):
                    print(f"[test] killing rollout worker {fail_worker_id}")
                    self.event_logger.emit(
                        "worker_kill_requested",
                        worker_id=fail_worker_id,
                        after_dispatches=dispatches,
                    )
                    ray.kill(self.rollout_workers[fail_worker_id], no_restart=True)
                    self._mark_worker_dead(fail_worker_id)
                    fail_triggered = True

            if not in_flight:
                continue

            ready, _ = ray.wait(list(in_flight.keys()), num_returns=1, timeout=0.2)
            for ref in ready:
                request_id, worker_id, attempt = in_flight.pop(ref)
                req = self.requests[request_id]
                try:
                    result = ray.get(ref)
                except ray.exceptions.RayActorError as exc:
                    print(f"[scheduler] actor error for {request_id} on {worker_id}: {exc}")
                    self.event_logger.emit(
                        "actor_error",
                        request_id=request_id,
                        worker_id=worker_id,
                        attempt=attempt,
                        error=str(exc),
                    )
                    self._mark_worker_dead(worker_id)
                    if (
                        req.status == "running"
                        and req.assigned_worker == worker_id
                        and req.attempts == attempt
                    ):
                        req.status = "pending"
                        req.assigned_worker = None
                    else:
                        print(
                            "[scheduler] ignore stale actor error "
                            f"{request_id} from {worker_id}, attempt={attempt}, "
                            f"current_status={req.status}, current_worker={req.assigned_worker}, "
                            f"current_attempt={req.attempts}"
                        )
                        self.event_logger.emit(
                            "stale_actor_error_ignored",
                            request_id=request_id,
                            worker_id=worker_id,
                            attempt=attempt,
                            current_status=req.status,
                            current_worker=req.assigned_worker,
                            current_attempt=req.attempts,
                        )
                    continue

                if worker_id in self.dead_workers:
                    print(f"[scheduler] ignore stale result {request_id} from dead worker {worker_id}")
                    self.event_logger.emit(
                        "stale_result_ignored",
                        request_id=request_id,
                        worker_id=worker_id,
                        attempt=attempt,
                        reason="dead_worker",
                    )
                    continue
                if req.status == "done":
                    print(f"[scheduler] ignore duplicate done result {request_id} from {worker_id}")
                    self.event_logger.emit(
                        "duplicate_done_result_ignored",
                        request_id=request_id,
                        worker_id=worker_id,
                        attempt=attempt,
                    )
                    continue
                if req.assigned_worker != worker_id or req.attempts != attempt:
                    print(
                        "[scheduler] ignore stale result "
                        f"{request_id} from {worker_id}, attempt={attempt}, "
                        f"current_status={req.status}, current_worker={req.assigned_worker}, "
                        f"current_attempt={req.attempts}"
                    )
                    self.event_logger.emit(
                        "stale_result_ignored",
                        request_id=request_id,
                        worker_id=worker_id,
                        attempt=attempt,
                        reason="attempt_or_worker_mismatch",
                        current_status=req.status,
                        current_worker=req.assigned_worker,
                        current_attempt=req.attempts,
                    )
                    continue

                req.status = "done"
                req.response = result["response"]
                record = TrajectoryRecord(
                    request_id=req.request_id,
                    prompt=req.prompt,
                    response=req.response,
                    model_version=req.model_version,
                    worker_id=worker_id,
                    hostname=result["hostname"],
                    node_id=result["node_id"],
                    attempts=req.attempts,
                    finished_at=time.time(),
                )
                self.trajectory_store.append(record)
                print(
                    f"[scheduler] done {request_id} by {worker_id} "
                    f"on {result['hostname']} node={result['node_id']}"
                )
                self.event_logger.emit(
                    "request_done",
                    request_id=request_id,
                    worker_id=worker_id,
                    hostname=result["hostname"],
                    node_id=result["node_id"],
                    attempt=req.attempts,
                    retried=req.attempts > 1,
                )

        not_done = [req for req in self.requests.values() if req.status != "done"]
        if not_done:
            raise RuntimeError(f"unfinished requests: {not_done}")
        self.event_logger.emit(
            "all_requests_done",
            total_requests=len(self.requests),
            retried_requests=sum(1 for req in self.requests.values() if req.attempts > 1),
        )

    def validate_trajectory_store(self) -> None:
        """Ensure the JSONL buffer has exactly one trajectory per request."""
        records = []
        with self.trajectory_store.path.open("r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    records.append(json.loads(line))

        expected = len(self.requests)
        seen_ids = [record["request_id"] for record in records]
        unique_ids = set(seen_ids)
        if len(records) != expected or len(unique_ids) != expected:
            duplicates = sorted({rid for rid in seen_ids if seen_ids.count(rid) > 1})
            raise RuntimeError(
                "trajectory buffer validation failed: "
                f"records={len(records)}, unique={len(unique_ids)}, expected={expected}, "
                f"duplicates={duplicates}"
            )
        self.event_logger.emit(
            "trajectory_store_validated",
            records=len(records),
            unique_request_ids=len(unique_ids),
            expected=expected,
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--num-requests", type=int, default=12)
    parser.add_argument("--model-version", type=int, default=1)
    parser.add_argument("--delay-sec", type=float, default=0.5)
    parser.add_argument(
        "--rollout-backend",
        choices=["mock", "vllm-openai", "sglang-generate"],
        default="mock",
        help="Use mock responses or call a real rollout HTTP server.",
    )
    parser.add_argument(
        "--rollout-endpoints",
        default="",
        help=(
            "Comma-separated endpoint URLs for rollout-0 and rollout-1. "
            "Required when rollout-backend is not mock, e.g. "
            "http://10.0.0.3:8000,http://10.0.0.4:8000"
        ),
    )
    parser.add_argument("--http-timeout-sec", type=float, default=120.0)
    parser.add_argument("--served-model-name", default="default")
    parser.add_argument("--max-tokens", type=int, default=64)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument("--fail-worker-id", default="rollout-0")
    parser.add_argument("--fail-after-dispatches", type=int, default=3)
    parser.add_argument(
        "--output-dir",
        default="./elastic_spot_experiments/mock_4node_outputs",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    ray.init(address="auto", ignore_reinit_error=True)

    print("[driver] Ray cluster resources:")
    print(ray.cluster_resources())

    train_workers = {
        "train-0": TrainWorker.options(resources={"train": 1}).remote("train-0"),
        "train-1": TrainWorker.options(resources={"train": 1}).remote("train-1"),
    }
    endpoints = [item.strip() for item in args.rollout_endpoints.split(",") if item.strip()]
    if args.rollout_backend != "mock" and len(endpoints) != 2:
        raise ValueError("--rollout-endpoints must contain exactly two URLs for non-mock backends")

    rollout_workers = {
        "rollout-0": RolloutWorker.options(resources={"rollout": 1}).remote(
            "rollout-0",
            args.delay_sec,
            args.rollout_backend,
            endpoints[0] if endpoints else None,
            args.http_timeout_sec,
            args.served_model_name,
            args.max_tokens,
            args.temperature,
        ),
        "rollout-1": RolloutWorker.options(resources={"rollout": 1}).remote(
            "rollout-1",
            args.delay_sec,
            args.rollout_backend,
            endpoints[1] if endpoints else None,
            args.http_timeout_sec,
            args.served_model_name,
            args.max_tokens,
            args.temperature,
        ),
    }

    print("[driver] train heartbeats:")
    for hb in ray.get([worker.heartbeat.remote() for worker in train_workers.values()]):
        print(hb)

    print("[driver] rollout heartbeats:")
    for hb in ray.get([worker.heartbeat.remote() for worker in rollout_workers.values()]):
        print(hb)

    output_dir = Path(args.output_dir)
    trajectory_store = JsonlTrajectoryStore(output_dir / "trajectories.jsonl")
    event_logger = JsonlEventLogger(output_dir / "events.jsonl")
    event_logger.emit(
        "experiment_started",
        num_requests=args.num_requests,
        model_version=args.model_version,
        fail_worker_id=args.fail_worker_id,
        fail_after_dispatches=args.fail_after_dispatches,
        cluster_resources=ray.cluster_resources(),
    )
    scheduler = InMemoryRolloutScheduler(
        rollout_workers=rollout_workers,
        trajectory_store=trajectory_store,
        event_logger=event_logger,
        max_attempts=args.max_attempts,
    )
    scheduler.submit_requests(count=args.num_requests, model_version=args.model_version)
    for req in scheduler.requests.values():
        # These fields are consumed by real HTTP rollout backends and ignored by
        # the mock backend.
        req.prompt = f"Answer briefly: {req.prompt}"
    scheduler.run_until_done(
        fail_worker_id=args.fail_worker_id,
        fail_after_dispatches=args.fail_after_dispatches,
    )
    scheduler.validate_trajectory_store()

    done = [req for req in scheduler.requests.values() if req.status == "done"]
    retried = [req for req in done if req.attempts > 1]
    print(f"[result] done={len(done)} total={len(scheduler.requests)} retried={len(retried)}")
    print(f"[result] trajectory_jsonl={trajectory_store.path}")
    print(f"[result] event_jsonl={event_logger.path}")
    event_logger.emit(
        "experiment_finished",
        done=len(done),
        total=len(scheduler.requests),
        retried=len(retried),
        trajectory_jsonl=str(trajectory_store.path),
        event_jsonl=str(event_logger.path),
    )

    print("[driver] train heartbeats after rollout failure/retry:")
    for hb in ray.get([worker.heartbeat.remote() for worker in train_workers.values()]):
        print(hb)

    ray.shutdown()


if __name__ == "__main__":
    main()
