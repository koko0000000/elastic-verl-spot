#!/usr/bin/env bash
set -euo pipefail
set -x

# Node 3/4: Ray worker with one H100 reserved for logical rollout.
# Run this same script on both rollout nodes.

RAY_HEAD_ADDR=${RAY_HEAD_ADDR:-10.245.247.247}
RAY_HEAD_PORT=${RAY_HEAD_PORT:-6379}

export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}

ray stop --force || true

ray start --address="${RAY_HEAD_ADDR}:${RAY_HEAD_PORT}" \
  --num-gpus=1 \
  --resources='{"rollout": 1}' \
  --block

