#!/usr/bin/env bash
set -euo pipefail
set -x

# Native verl synchronous GRPO baseline on one 4-GPU 4090 instance.
# This does not implement elastic rollout yet. It only verifies that the local
# environment can run a small GRPO step with verl.trainer.main_ppo.

MODEL_PATH=${MODEL_PATH:-"/inspire/hdd/global_public/public_models/Qwen/Qwen2.5-0.5B-Instruct"}
DATA_DIR=${DATA_DIR:-"/inspire/hdd/project/ruanyinyitihua/czxs253130626/klg/verl/data/gsm8k"}
OUTPUT_DIR=${OUTPUT_DIR:-"/inspire/hdd/project/ruanyinyitihua/czxs253130626/klg/verl/elastic_spot_experiments/baseline_outputs"}

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-"0,1,2,3"}
export VLLM_USE_V1=${VLLM_USE_V1:-1}
export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}

export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=1
export NCCL_IB_DISABLE=1
export NCCL_DEBUG=INFO

mkdir -p "${OUTPUT_DIR}/logs"
mkdir -p "${OUTPUT_DIR}/rollout_data"

ray stop --force || true
ray start --head \
  --node-ip-address=127.0.0.1 \
  --port=6379 \
  --dashboard-host=0.0.0.0 \
  --dashboard-port=8265 \
  --num-gpus=4

export RAY_ADDRESS=${RAY_ADDRESS:-"127.0.0.1:6379"}

NOW=${NOW:-$(date +%Y%m%d_%H%M%S)}
LOG_FILE="${OUTPUT_DIR}/logs/grpo_sync_4gpu4090_${NOW}.log"

python3 -u -m verl.trainer.main_ppo \
  --config-path=config \
  --config-name=ppo_trainer.yaml \
  data.train_files="${DATA_DIR}/train.parquet" \
  data.val_files="${DATA_DIR}/test.parquet" \
  data.max_prompt_length=256 \
  data.max_response_length=512 \
  data.train_batch_size=8 \
  data.val_batch_size=8 \
  data.shuffle=False \
  data.filter_overlong_prompts=False \
  data.truncation=left \
  algorithm.adv_estimator=grpo \
  algorithm.use_kl_in_reward=False \
  algorithm.norm_adv_by_std_in_grpo=True \
  actor_rollout_ref.model.path="${MODEL_PATH}" \
  actor_rollout_ref.model.use_remove_padding=True \
  actor_rollout_ref.model.enable_gradient_checkpointing=True \
  actor_rollout_ref.hybrid_engine=True \
  actor_rollout_ref.actor.strategy=fsdp \
  actor_rollout_ref.actor.optim.lr=1e-6 \
  actor_rollout_ref.actor.ppo_mini_batch_size=8 \
  actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.actor.use_dynamic_bsz=True \
  actor_rollout_ref.actor.use_kl_loss=False \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.rollout.name=vllm \
  actor_rollout_ref.rollout.mode=sync \
  actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.35 \
  actor_rollout_ref.rollout.n=2 \
  actor_rollout_ref.rollout.max_num_seqs=8 \
  actor_rollout_ref.rollout.max_model_len=768 \
  actor_rollout_ref.rollout.max_num_batched_tokens=768 \
  actor_rollout_ref.rollout.enforce_eager=True \
  actor_rollout_ref.rollout.calculate_log_probs=True \
  actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=1 \
  trainer.logger='["console"]' \
  trainer.project_name=elastic_verl_spot \
  trainer.experiment_name=grpo_sync_4gpu4090_baseline \
  trainer.n_gpus_per_node=4 \
  trainer.nnodes=1 \
  trainer.total_training_steps=3 \
  trainer.test_freq=-1 \
  trainer.save_freq=-1 \
  trainer.val_before_train=False \
  trainer.rollout_data_dir="${OUTPUT_DIR}/rollout_data" \
  trainer.resume_mode=disable \
  "$@" 2>&1 | tee "${LOG_FILE}"

