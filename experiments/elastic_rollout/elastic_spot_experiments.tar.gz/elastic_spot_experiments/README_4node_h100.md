# 4-Node H100 Rollout-Exit Mock Experiment

This experiment runs on four physical nodes, each with one H100.

- Node 1: Ray head, driver, and one logical train worker.
- Node 2: one logical train worker.
- Node 3: one logical rollout worker.
- Node 4: one logical rollout worker.

Ray custom resources are used to separate roles:

- train nodes start with `--resources='{"train": 1}'`
- rollout nodes start with `--resources='{"rollout": 1}'`

## Start Order

On node 1:

```bash
cd /path/to/verl-src
bash elastic_spot_experiments/run_4node_h100_head_train.sh
```

Record the printed head address, then on node 2:

```bash
cd /path/to/verl-src
RAY_HEAD_ADDR=<HEAD_NODE_IP> \
bash elastic_spot_experiments/run_4node_h100_train_worker.sh
```

On node 3 and node 4:

```bash
cd /path/to/verl-src
RAY_HEAD_ADDR=<HEAD_NODE_IP> \
bash elastic_spot_experiments/run_4node_h100_rollout_worker.sh
```

Back on node 1, verify the cluster:

```bash
ray status
```

Expected resources include:

- 4 GPUs
- 2 train resources
- 2 rollout resources

Then run:

```bash
python3 -u elastic_spot_experiments/mock_4node_h100_rollout_exit.py
```

## What It Verifies

- training actors are scheduled onto train nodes;
- rollout actors are scheduled onto rollout nodes;
- one rollout actor is killed during request processing;
- unfinished requests from the killed rollout worker are requeued;
- the surviving rollout worker completes retried requests;
- trajectory JSONL contains exactly one record per request;
- training actor heartbeat still works after rollout failure.

## Output

The trajectory buffer is written to:

```text
elastic_spot_experiments/mock_4node_outputs/trajectories.jsonl
```

Each record contains `hostname` and `node_id` so the physical location of the
rollout worker can be verified.

