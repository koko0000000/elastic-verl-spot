#!/usr/bin/env bash
set -euo pipefail
set -x

# Start a vLLM OpenAI-compatible server on one rollout node.
# Run this on each rollout node before running the HTTP rollout-exit driver.

MODEL_PATH=${MODEL_PATH:-/inspire/hdd/global_public/public_models/Qwen/Qwen2.5-0.5B-Instruct}
SERVED_MODEL_NAME=${SERVED_MODEL_NAME:-elastic-rollout-model}
HOST=${HOST:-0.0.0.0}
PORT=${PORT:-8000}
GPU_MEMORY_UTILIZATION=${GPU_MEMORY_UTILIZATION:-0.75}
MAX_MODEL_LEN=${MAX_MODEL_LEN:-1024}
TENSOR_PARALLEL_SIZE=${TENSOR_PARALLEL_SIZE:-1}

export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}

python3 -m vllm.entrypoints.openai.api_server \
  --model "${MODEL_PATH}" \
  --served-model-name "${SERVED_MODEL_NAME}" \
  --host "${HOST}" \
  --port "${PORT}" \
  --tensor-parallel-size "${TENSOR_PARALLEL_SIZE}" \
  --gpu-memory-utilization "${GPU_MEMORY_UTILIZATION}" \
  --max-model-len "${MAX_MODEL_LEN}"

