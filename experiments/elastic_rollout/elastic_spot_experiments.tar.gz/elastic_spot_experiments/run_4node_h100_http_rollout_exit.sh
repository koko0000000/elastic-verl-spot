#!/usr/bin/env bash
set -euo pipefail
set -x

# Run the 4-node rollout-exit driver with real HTTP rollout servers.
# Start Ray on all four nodes first, then start one vLLM/SGLang HTTP server on
# each rollout node. Finally run this script on the Ray head.

ROLLOUT_BACKEND=${ROLLOUT_BACKEND:-vllm-openai}
ROLLOUT_ENDPOINTS=${ROLLOUT_ENDPOINTS:-http://10.244.43.89:8000,http://10.246.78.233:8000}
SERVED_MODEL_NAME=${SERVED_MODEL_NAME:-elastic-rollout-model}
NUM_REQUESTS=${NUM_REQUESTS:-12}
MAX_TOKENS=${MAX_TOKENS:-64}
TEMPERATURE=${TEMPERATURE:-1.0}
FAIL_WORKER_ID=${FAIL_WORKER_ID:-rollout-0}
FAIL_AFTER_DISPATCHES=${FAIL_AFTER_DISPATCHES:-3}
OUTPUT_DIR=${OUTPUT_DIR:-./elastic_spot_experiments/http_4node_outputs}

export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-1}

python3 -u elastic_spot_experiments/mock_4node_h100_rollout_exit.py \
  --rollout-backend "${ROLLOUT_BACKEND}" \
  --rollout-endpoints "${ROLLOUT_ENDPOINTS}" \
  --served-model-name "${SERVED_MODEL_NAME}" \
  --num-requests "${NUM_REQUESTS}" \
  --max-tokens "${MAX_TOKENS}" \
  --temperature "${TEMPERATURE}" \
  --fail-worker-id "${FAIL_WORKER_ID}" \
  --fail-after-dispatches "${FAIL_AFTER_DISPATCHES}" \
  --output-dir "${OUTPUT_DIR}" \
  "$@"

